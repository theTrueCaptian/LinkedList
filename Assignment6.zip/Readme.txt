Here is how to run:
java -jar "F:\linkedListNetbeans\dist\linkedListNetbeans.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
******************************************************************************